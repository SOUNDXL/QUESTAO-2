// Testando a função combinacao
const n = 5;
const k = 2;
const resultado = combinacao(n, k);
console.log(`O número de combinações de ${n} elementos tomados ${k} a ${k} é: ${resultado}`);